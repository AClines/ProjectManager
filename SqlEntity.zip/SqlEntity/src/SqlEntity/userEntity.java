package SqlEntity;

public class userEntity {
	public int userNum;//�û���ţ��������Զ�����ֵ
	public int teamNum;//�Ŷӱ�ţ����������team��
	public String userName;//�û�����
	public int userAccount;//�û��˺�
	public String userPassword;//�û�����
	public int userPhone;//�û��ֻ���
	public String userInformation;//���˼��
	public String userSex;//�Ա�
	public String userEmail;//����
	
	//get��set����
	public int getUserNum() {
		return userNum;
	}
	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}
	public int getTeamNum() {
		return teamNum;
	}
	public void setTeamNum(int teamNum) {
		this.teamNum = teamNum;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getUserAccount() {
		return userAccount;
	}
	public void setUserAccount(int userAccount) {
		this.userAccount = userAccount;
	}
	public char getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(char userPassword) {
		this.userPassword = userPassword;
	}
	public int getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(int userPhone) {
		this.userPhone = userPhone;
	}
	public char getUserInformation() {
		return userInformation;
	}
	public void setUserInformation(char userInformation) {
		this.userInformation = userInformation;
	}
	public char getUserSex() {
		return userSex;
	}
	public void setUserSex(char userSex) {
		this.userSex = userSex;
	}
	public char getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(char userEmail) {
		this.userEmail = userEmail;
	}
	
	//toString����
	@Override
	public String toString() {
		return "userEntity [userNum=" + userNum + ", teamNum=" + teamNum + ", userName=" + userName + ", userAccount="
				+ userAccount + ", userPassword=" + userPassword + ", userPhone=" + userPhone + ", userInformation="
				+ userInformation + ", userSex=" + userSex + ", userEmail=" + userEmail + "]";
	}
	
	
	
}
